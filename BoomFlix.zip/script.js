function getUsers(){ return JSON.parse(localStorage.getItem('users'))||{}; }
function saveUsers(users){ localStorage.setItem('users', JSON.stringify(users)); }

let currentUser = null;

function registerUser(){
  let username=document.getElementById('usernameAuth').value.trim();
  let password=document.getElementById('passwordAuth').value.trim();
  if(!username||!password){ showAuthResult('Enter valid details!','red'); return; }
  let users=getUsers();
  if(users[username]){ showAuthResult('Username already exists!','red'); return; }
  users[username]={password:password, watchlist:[]};
  saveUsers(users);
  showAuthResult('Registered successfully!','green');
}

function loginUser(){
  let username=document.getElementById('usernameAuth').value.trim();
  let password=document.getElementById('passwordAuth').value.trim();
  let users=getUsers();
  if(users[username] && users[username].password===password){
    currentUser=username;
    showHome();
  } else showAuthResult('Invalid credentials!','red');
}

function showAuthResult(msg,color){ const r=document.getElementById('authResult'); r.style.color=color; r.textContent=msg; }

function showHome(){
  document.getElementById('authSection').classList.add('hidden');
  document.getElementById('homeSection').classList.remove('hidden');
  document.getElementById('watchlistSection').classList.add('hidden');
  loadMovies();
}

function logout(){ currentUser=null; document.getElementById('authSection').classList.remove('hidden'); document.getElementById('homeSection').classList.add('hidden'); document.getElementById('watchlistSection').classList.add('hidden'); document.getElementById('authResult').textContent=''; }

function showSection(section){
  document.getElementById('homeSection').classList.add('hidden');
  document.getElementById('watchlistSection').classList.add('hidden');
  if(section==='home') document.getElementById('homeSection').classList.remove('hidden');
  else if(section==='watchlist') loadWatchlist();
}

const movies=[
  {title:'Movie 1',img:'https://images.unsplash.com/photo-1524985069026-dd778a71c7b4',trailer:'https://www.youtube.com/embed/ScMzIvxBSi4'},
  {title:'Movie 2',img:'https://images.unsplash.com/photo-1542206395-9feb3edaa68f',trailer:'https://www.youtube.com/embed/ysz5S6PUM-U'},
  {title:'Movie 3',img:'https://images.unsplash.com/photo-1505685296765-3a2736de412f',trailer:'https://www.youtube.com/embed/dQw4w9WgXcQ'},
  {title:'Movie 4',img:'https://images.unsplash.com/photo-1581905764498-8f5c6ef3c127',trailer:'https://www.youtube.com/embed/tgbNymZ7vqY'}
];

function loadMovies(){
  const list=document.getElementById('movieList');
  list.innerHTML='';
  movies.forEach(m=>{
    const div=document.createElement('div'); div.className='movie-card';
    div.innerHTML=`<img src="${m.img}" alt="${m.title}"><h4>${m.title}</h4>`;
    div.onclick=()=>{ document.getElementById('trailer').src=m.trailer; addToWatchlist(m); };
    list.appendChild(div);
  });
}

function addToWatchlist(movie){
  if(!currentUser) return;
  let users=getUsers();
  let watchlist=users[currentUser].watchlist;
  if(!watchlist.find(m=>m.title===movie.title)){ watchlist.push(movie); users[currentUser].watchlist=watchlist; saveUsers(users); alert(movie.title+' added to watchlist!'); }
}

function loadWatchlist(){
  document.getElementById('homeSection').classList.add('hidden');
  document.getElementById('watchlistSection').classList.remove('hidden');
  const div=document.getElementById('watchlistMovies'); div.innerHTML='';
  let users=getUsers();
  let watchlist=users[currentUser].watchlist;
  watchlist.forEach(m=>{
    const card=document.createElement('div'); card.className='movie-card';
    card.innerHTML=`<img src="${m.img}" alt="${m.title}"><h4>${m.title}</h4>`;
    card.onclick=()=>{ document.getElementById('trailer').src=m.trailer; showSection('home'); };
    div.appendChild(card);
  });
}
